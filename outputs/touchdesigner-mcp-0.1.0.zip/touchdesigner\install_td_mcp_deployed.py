# 此文件由部署流程生成，请勿分享。
exec(open(r'C:\Users\POLAN\Documents\Codex\2026-06-20\zhe\touchdesigner\install_td_mcp.py', encoding='utf-8').read())
_bridge = op('/project1/td_mcp_bridge')
_bridge.par["Token"] = 'b41ac5c47baa96016fc264d24b5788e6dfeb30e8b059aced1b5877ad05f08946'
_bridge.op('webserver').par.active = True
print('TouchDesigner MCP deployment ready on http://127.0.0.1:9980/api')